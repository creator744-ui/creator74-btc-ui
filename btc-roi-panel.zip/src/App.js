import React from 'react';

function App() {
  return (
    <div style={{ padding: 30 }}>
      <h1>BTC ROI Panel</h1>
      <p>This is your basic frontend template ready to deploy.</p>
    </div>
  );
}

export default App;